Imports System.Web.Services

<System.Web.Services.WebService(Namespace:="http://tempuri.org/ResumeWebService/Service1")> _
Public Class Submit
    Inherits System.Web.Services.WebService

    <WebMethod()> _
    Public Function SubmitResume(ByVal strXML As String) As String

        Try
            Dim UserName As String = "sa"
            Dim Password As String = ""

            'Set up connection string from custom properties
            Dim strConnection As String
            strConnection += "Password=" & Password
            strConnection += ";Persist Security Info=True;User ID="
            strConnection += UserName + ";Initial Catalog=Resume"
            strConnection += ";Data Source=(local)"

            'Create the insert statement
            Dim ResumeName As String = "Admin" + Now.ToString
            Dim strSQL As String = _
            "INSERT INTO tblUser (username,password) " + _
    "VALUES('" + ResumeName + "','password')"

            'Insert user name
            Dim objCommand As New System.Data.SqlClient.SqlCommand

            With objCommand
                .Connection = New System.Data.SqlClient.SqlConnection(strConnection)
                .Connection.Open()
                .CommandText = strSQL
                Dim intRows = .ExecuteNonQuery()
                .Connection.Close()
            End With

            strSQL = _
            "INSERT INTO tblResume " + _
    " (owner,name,description,lastChanged,DocData) VALUES('" + _
    ResumeName + "','" + _
    ResumeName + "','test resume','" + Now + "','" + strXML + "')"

            'Insert resume
            With objCommand
                .Connection.Open()
                .CommandText = strSQL
                Dim intRows = .ExecuteNonQuery()
                .Connection.Close()
            End With

            Return ""

        Catch x As Exception
            Return x.Message
        End Try

    End Function

End Class

